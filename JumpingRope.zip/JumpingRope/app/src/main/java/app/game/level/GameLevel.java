package app.game.level;

import ryulib.game.GameControl;
import ryulib.game.GameControlGroup;

public class GameLevel extends GameControl {

	public GameLevel(GameControlGroup gameControlGroup) {
		super(gameControlGroup);
		// TODO Auto-generated constructor stub
	}

}
