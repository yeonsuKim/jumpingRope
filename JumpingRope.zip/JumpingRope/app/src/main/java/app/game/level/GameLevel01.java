package app.game.level;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import app.scene.SceneGame;
import ryulib.game.GameControlGroup;
import ryulib.game.GamePlatformInfo;

public class GameLevel01 extends GameLevel {

	public GameLevel01(GameControlGroup gameControlGroup) {
		super(gameControlGroup);
		// TODO Auto-generated constructor stub
	}

	private Canvas _Canvas = null;
	private Paint _Paint = null;

	@Override
	protected void onStart(GamePlatformInfo platformInfo) {
		_Canvas = platformInfo.getCanvas();
		_Paint = platformInfo.getPaint();
	}

	@Override
	protected void onDraw(GamePlatformInfo platformInfo) {
		_Paint.setARGB(255, 0, 0, 0);
		_Canvas.drawRect(0, 0, _Canvas.getWidth(), _Canvas.getHeight(), _Paint);

		_Paint.setARGB(255, 255, 255, 255);
		_Canvas.drawText("GameLevel01...", 100, 100, _Paint);
	}
	
	@Override
    protected boolean onTouchEvent(GamePlatformInfo platformInfo, MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {		
			SceneGame.getInstance().setGameLevel(2);
		}

		return true;
    }

}
