package app.game.level;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import app.scene.SceneGame;
import ryulib.game.GameControlGroup;
import ryulib.game.GamePlatformInfo;

public class GameLevel02 extends GameLevel {

	public GameLevel02(GameControlGroup gameControlGroup) {
		super(gameControlGroup);
		
		gameControlGroup.addControl(this);
	}
	
	private Canvas _Canvas = null;
	private Paint _Paint = null;

	@Override
	protected void onStart(GamePlatformInfo platformInfo) {
		_Canvas = platformInfo.getCanvas();
		_Paint = platformInfo.getPaint();
	}

	@Override
	protected void onDraw(GamePlatformInfo platformInfo) {
		_Paint.setARGB(255, 0, 0, 0);
		_Canvas.drawRect(0, 0, _Canvas.getWidth(), _Canvas.getHeight(), _Paint);

		_Paint.setARGB(255, 255, 255, 255);
		_Canvas.drawText("GameLevel02...", 100, 100, _Paint);
	}	

	@Override
    protected boolean onTouchEvent(GamePlatformInfo platformInfo, MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {		
			SceneGame.getInstance().setGameLevel(3);
		}

		return true;
    }

}
