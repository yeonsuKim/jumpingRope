package app.main;

import ryulib.game.GamePlatform;
import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import app.scene.SceneManager;

public class Main extends Activity {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        _GamePlatform = new GamePlatform(this);
        _GamePlatform.setUseMotionEvent(true);
        _GamePlatform.setLayoutParams(
        		new LinearLayout.LayoutParams(
        				ViewGroup.LayoutParams.FILL_PARENT,
        				ViewGroup.LayoutParams.FILL_PARENT,
        				0.0F
        		)
        );
        setContentView(_GamePlatform);
        
        SceneManager.getInstance().setGameControlGroup(_GamePlatform.getGameControlGroup());
        SceneManager.getInstance().begin(null);
    }
        
	private GamePlatform _GamePlatform = null;
	
}