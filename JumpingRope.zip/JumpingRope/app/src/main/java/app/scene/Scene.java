package app.scene;

import ryulib.ValueList;
import ryulib.game.GameControl;
import ryulib.game.GameControlGroup;

public class Scene extends GameControl {

	public Scene(GameControlGroup gameControlGroup) {
		super(gameControlGroup);

		setVisible(false);
	}
	
	final void doActionIn(Scene oldScene, ValueList params) {
		setVisible(true);
		actionIn(oldScene, params);
	}
	
	public void actionIn(Scene oldScene, ValueList params) {
		// Override �ؼ� ���
	}
	
	final void doActionOut(Scene newScene) {
		setVisible(false);
		actionOut(newScene);
	}

	public void actionOut(Scene newScene) {
		// Override �ؼ� ���
	}
	
}
