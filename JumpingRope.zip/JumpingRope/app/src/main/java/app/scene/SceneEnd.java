package app.scene;

import ryulib.game.GameControlGroup;

public class SceneEnd extends Scene {

	public SceneEnd(GameControlGroup gameControlGroup) {
		super(gameControlGroup);
		
		gameControlGroup.addControl(this);
	}

}
