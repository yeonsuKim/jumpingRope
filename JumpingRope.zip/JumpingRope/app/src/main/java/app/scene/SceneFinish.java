package app.scene;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import ryulib.ValueList;
import ryulib.game.GameControlGroup;
import ryulib.game.GamePlatformInfo;

public class SceneFinish extends Scene {

	public SceneFinish(GameControlGroup gameControlGroup) {
		super(gameControlGroup);
		
		gameControlGroup.addControl(this);
	}

	private Canvas _Canvas = null;
	private Paint _Paint = null;
	private Bitmap _Bitmap = null;
	private long _DisplayTime = 0;

	@Override
	public void actionIn(Scene oldScene, ValueList params) {
		_DisplayTime = 2000;
	}

	@Override
	public void actionOut(Scene oldScene) {
		_Bitmap = null;
	}

	@Override
	protected void onStart(GamePlatformInfo platformInfo) {
		_Canvas = platformInfo.getCanvas();
		_Paint = platformInfo.getPaint();
	}

	@Override
	protected void onDraw(GamePlatformInfo platformInfo) {
		_DisplayTime = _DisplayTime - platformInfo.getTick();
		if (_DisplayTime <= 0) {
			System.exit(0);
			return;
		}
		
		if (_Bitmap == null) {
			_Bitmap = BitmapFactory.decodeResource(
					platformInfo.getGamePlatform().getContext().getResources(), 
					app.main.R.drawable.finish);
		}
		
		_Canvas.drawBitmap(_Bitmap, 0, 0, _Paint);
	}

}
