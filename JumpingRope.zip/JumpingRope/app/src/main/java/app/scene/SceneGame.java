package app.scene;

import ryulib.ValueList;
import ryulib.game.GameControlGroup;
import app.game.level.GameLevel;
import app.game.level.GameLevel01;
import app.game.level.GameLevel02;
import app.game.level.GameLevel03;

public class SceneGame extends Scene {

	private static SceneGame _MyObject = null;

	public SceneGame(GameControlGroup gameControlGroup) {
		super(gameControlGroup);
		
		_MyObject = this;
		
		gameControlGroup.addControl(this);
	}
	
	public static SceneGame getInstance() {
	    return _MyObject;
	}
	
	private GameLevel _GameLevel = null;
	
	public void setGameLevel(int level) {
		if (_GameLevel != null) {
			_GameLevel.delete();
			_GameLevel = null;
		}
		
		switch (level) {
			case 1: _GameLevel = new GameLevel01(getGameControlGroup()); break;
			case 2: _GameLevel = new GameLevel02(getGameControlGroup()); break;
			case 3: _GameLevel = new GameLevel03(getGameControlGroup()); break;
			default: ; // TODO : raise Exception
		}
		
		getGameControlGroup().addControl(_GameLevel);
	}
	
	@Override
	public void actionIn(Scene oldScene, ValueList params) {
		setGameLevel(1);
	}

	@Override
	public void actionOut(Scene newScene) {
		if (_GameLevel != null) {
			_GameLevel.delete();
			_GameLevel = null;
		}
	}
	
}
