package app.scene;

import ryulib.OnNotifyEventListener;
import ryulib.ValueList;
import ryulib.game.GameControlGroup;
import ryulib.game.GamePlatformInfo;
import ryulib.game.ImageButton;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import app.main.R;

public class SceneMain extends Scene {

	public SceneMain(GameControlGroup gameControlGroup) {
		super(gameControlGroup);
		
		gameControlGroup.addControl(this);
	}

	private Canvas _Canvas = null;
	private Paint _Paint = null;
	private Bitmap _Bitmap = null;
	
	private ImageButton _btOption = null;
	private ImageButton _btGame = null;
	private ImageButton _btExit = null;

	@Override
	public void actionIn(Scene oldScene, ValueList params) {
		_btOption = new ImageButton(getGameControlGroup());
		_btOption.getPaint().setTextSize(16);
		_btOption.getPaint().setTypeface(Typeface.DEFAULT_BOLD);
		_btOption.setCaption("Option");
		_btOption.setPosition(235, 24);
		_btOption.setImageUp(R.drawable.btn_up);
		_btOption.setImageDown(R.drawable.btn_dn);
		_btOption.setOnClick(_OnOptionClick);

		_btGame = new ImageButton(getGameControlGroup());
		_btGame.getPaint().setTextSize(16);
		_btGame.getPaint().setTypeface(Typeface.DEFAULT_BOLD);
		_btGame.setCaption("Start Game");
		_btGame.setPosition(235, 24 + 80*1);
		_btGame.setImageUp(R.drawable.btn_up);
		_btGame.setImageDown(R.drawable.btn_dn);
		_btGame.setOnClick(_OnGameClick);

		_btExit = new ImageButton(getGameControlGroup());
		_btExit.getPaint().setTextSize(16);
		_btExit.getPaint().setTypeface(Typeface.DEFAULT_BOLD);
		_btExit.setCaption("Exit");
		_btExit.setPosition(235, 24 + 80*2);
		_btExit.setImageUp(R.drawable.btn_up);
		_btExit.setImageDown(R.drawable.btn_dn);
		_btExit.setOnClick(_OnExitClick);
	}

	@Override
	public void actionOut(Scene newScene) {
		_Bitmap = null;
		
		_btOption.delete();
		_btOption = null;
		
		_btGame.delete();
		_btGame = null;
		
		_btExit.delete();
		_btExit = null;		
	}
	
	@Override
	protected void onStart(GamePlatformInfo platformInfo) {
		_Canvas = platformInfo.getCanvas();
		_Paint = platformInfo.getPaint();
	}

	@Override
	protected void onDraw(GamePlatformInfo platformInfo) {
		if (_Bitmap == null) {
			_Bitmap = BitmapFactory.decodeResource(
					platformInfo.getGamePlatform().getContext().getResources(), 
					app.main.R.drawable.main);
		}
		
		_Canvas.drawBitmap(_Bitmap, 0, 0, _Paint);
	}
	
	private OnNotifyEventListener _OnOptionClick = new OnNotifyEventListener() {
		@Override
		public void onNotify(Object sender) {
			SceneManager.getInstance().option(null);
		}
	};

	private OnNotifyEventListener _OnGameClick = new OnNotifyEventListener() {
		@Override
		public void onNotify(Object sender) {
			SceneManager.getInstance().game(null);
		}
	};

	private OnNotifyEventListener _OnExitClick = new OnNotifyEventListener() {
		@Override
		public void onNotify(Object sender) {
			SceneManager.getInstance().finish(null);
		}
	};

}
