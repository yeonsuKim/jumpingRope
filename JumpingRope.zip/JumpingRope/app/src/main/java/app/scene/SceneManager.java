package app.scene;

import ryulib.ValueList;
import ryulib.game.GameControlGroup;


public class SceneManager {
	
	private static SceneManager _MyObject = new SceneManager();

	private SceneManager() {}

	public static SceneManager getInstance() {
	    return _MyObject;
	}
	
	private GameControlGroup _GameControlGroup = null;
	
	private Scene _Scene = null;
	private SceneBegin _SceneBegin = null;
	private SceneMain _SceneMain = null;
	private SceneOption _SceneOption = null;
	private SceneGame _SceneGame = null;
	private SceneResult _SceneResult = null;
	private SceneFinish _SceneFinish = null;
	private SceneEnd _SceneEnd = null;
	  
	public void begin(ValueList params) {
		if (_SceneBegin == null) _SceneBegin = new SceneBegin(_GameControlGroup);
		setScene(_SceneBegin, params);
	}
	
	public void main(ValueList params) {
		if (_SceneMain == null) _SceneMain = new SceneMain(_GameControlGroup);
		setScene(_SceneMain, params);
	}

	public void option(ValueList params) {
		if (_SceneOption == null) _SceneOption = new SceneOption(_GameControlGroup);
		setScene(_SceneOption, params);
	}

	public void game(ValueList params) {
		if (_SceneGame == null) _SceneGame = new SceneGame(_GameControlGroup);
		setScene(_SceneGame, params);
	}

	public void result(ValueList params) {
		if (_SceneResult == null) _SceneResult = new SceneResult(_GameControlGroup);
		setScene(_SceneResult, params);
	}

	public void finish(ValueList params) {
		if (_SceneFinish == null) _SceneFinish = new SceneFinish(_GameControlGroup);
		setScene(_SceneFinish, params);
	}

	public void end(ValueList params) {
		if (_SceneEnd == null) _SceneEnd = new SceneEnd(_GameControlGroup);
		setScene(_SceneEnd, params);
	}

	public void setGameControlGroup(GameControlGroup value) {
		_GameControlGroup = value;
	}

	public GameControlGroup getGameControlGroup() {
		return _GameControlGroup;
	}

	public void setScene(Scene value, ValueList params) {
		Scene temp = _Scene;
		_Scene = value;
		
		if (temp != null) temp.doActionOut(_Scene);
		if (_Scene != null) _Scene.doActionIn(temp, params);
	}

	public Scene getScene() {
		return _Scene;
	}
	
}
