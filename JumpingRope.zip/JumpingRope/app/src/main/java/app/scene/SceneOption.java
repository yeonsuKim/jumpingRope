package app.scene;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import app.main.R;
import ryulib.OnNotifyEventListener;
import ryulib.ValueList;
import ryulib.game.GameControlGroup;
import ryulib.game.GamePlatformInfo;
import ryulib.game.ImageButton;

public class SceneOption extends Scene {

	public SceneOption(GameControlGroup gameControlGroup) {
		super(gameControlGroup);
		
		gameControlGroup.addControl(this);
	}

	private Canvas _Canvas = null;
	private Paint _Paint = null;
	private Bitmap _Bitmap = null;

	private ImageButton _btClose = null;

	@Override
	public void actionIn(Scene oldScene, ValueList params) {
		_btClose = new ImageButton(getGameControlGroup());
		_btClose.getPaint().setTextSize(16);
		_btClose.getPaint().setTypeface(Typeface.DEFAULT_BOLD);
		_btClose.setCaption("Close");
		_btClose.setPosition(235, 24);
		_btClose.setImageUp(R.drawable.btn_up);
		_btClose.setImageDown(R.drawable.btn_dn);
		_btClose.setOnClick(_OnCloseClick);
	}

	@Override
	public void actionOut(Scene newScene) {
		_Bitmap = null;
		
		_btClose.delete();
		_btClose = null;
	}
	
	@Override
	protected void onStart(GamePlatformInfo platformInfo) {
		_Canvas = platformInfo.getCanvas();
		_Paint = platformInfo.getPaint();
	}

	@Override
	protected void onDraw(GamePlatformInfo platformInfo) {
		if (_Bitmap == null) {
			_Bitmap = BitmapFactory.decodeResource(
					platformInfo.getGamePlatform().getContext().getResources(), 
					app.main.R.drawable.options);
		}
		
		_Canvas.drawBitmap(_Bitmap, 0, 0, _Paint);
	}
	
	private OnNotifyEventListener _OnCloseClick = new OnNotifyEventListener() {
		@Override
		public void onNotify(Object sender) {
			SceneManager.getInstance().main(null);
		}
	};

}
