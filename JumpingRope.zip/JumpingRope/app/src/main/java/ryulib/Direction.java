package ryulib;

public enum Direction {
	NoWhere,
	Left, Right,
	Up, Down
}
