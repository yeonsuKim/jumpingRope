package ryulib;

import android.os.Message;

public interface OnHandlerMessageListener {

	public void onReceived(Message msg);
	
}
