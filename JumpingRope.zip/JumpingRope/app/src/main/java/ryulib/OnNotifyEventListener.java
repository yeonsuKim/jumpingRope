package ryulib;

public interface OnNotifyEventListener {

	public void onNotify(Object sender);
	
}
