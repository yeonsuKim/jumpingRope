package ryulib;

public interface OnTimerListener {

	public void onTime(long ATick);
	
}
