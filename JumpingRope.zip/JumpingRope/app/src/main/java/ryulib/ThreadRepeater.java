package ryulib;

import android.util.Log;

public class ThreadRepeater implements Runnable {
	
	private Boolean _Active = false; 
	private Boolean _Pause = false; 
	private Thread _Thread = null;
	
	// Property
	private long _Interval = 0;
	
	// Event
	private OnNotifyEventListener _OnNotifyEvent = null;

	public final void start() {
		_Active = true;
		_Thread = new Thread(this);
		_Thread.start();
	}
	
	public final void pause() {
		_Pause = true;
	}
	
	public final void resume() {
		_Pause = false;
	}
	
	public final void sleep(long time) {
		try {
    		Thread.sleep(time);
		} catch (InterruptedException e) {
			Log.w("GamePlatform Class", "Thread.sleep Exception.");
		}       		
	}
	
	public final void stop() {
        _Active = false;
        if (_Thread == null) return;
	}

	public final void termiate() {
        _Active = false;
        if (_Thread == null) return;
        
        Thread temp = _Thread;
        _Thread = null;

        boolean retry = true;
        while (retry) {
            try {
            	temp.join();
                retry = false;
            } catch (InterruptedException e) {
            }
        }
	}

	public final void run() {
		while (_Active) {
			if ((_Pause == false) && (_OnNotifyEvent != null)) {
				_OnNotifyEvent.onNotify(this);
        		if (_Interval > 0) sleep(_Interval);
			} else {
				// _Pause�� ���� Repeater�� �� ���� ���� ���� CPU �������� ���߱����ؼ� sleep
				sleep(5);
			}
		}
		
        _Thread = null;
	}
	
	public final void setOnNotifyEvent(OnNotifyEventListener value) {
		_OnNotifyEvent = value;
	}

	public final void setInterval(long value) {
		_Interval = value;
	}

	public final long getInterval() {
		return _Interval;
	}

}
