package ryulib.dialogs;

public interface OnFileSelectedListener {
	
	public void onSelected(String path, String fileName);

}
