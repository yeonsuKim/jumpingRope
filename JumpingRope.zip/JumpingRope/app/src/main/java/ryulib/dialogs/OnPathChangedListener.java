package ryulib.dialogs;

public interface OnPathChangedListener {
	
	public void onChanged(String path);

}
