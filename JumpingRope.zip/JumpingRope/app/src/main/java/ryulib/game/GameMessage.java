package ryulib.game;

public class GameMessage {
	
	public int what = 0;
	public int arg1 = 0;
	public int arg2 = 0;
	public String str = "";
	public Object sender = null;
	public Object obj = null;

}
